const socket=io('http://localhost:8080');

const form=document.getElementById('send=container');
const messageInput=document.getElementById('messageInp')
const messagecontainer=document.querySelector(".container")


const name=prompt("enter your name to join");
socket.emit('new-user-joined', name)